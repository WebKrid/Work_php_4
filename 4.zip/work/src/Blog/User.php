<?php
namespace GeekBrains\LevelTwo\Blog;
use GeekBrains\LevelTwo\Person\Name;

class User
{
    private int $id;
    private Name $username;
    private string $login;
    /**
     * Summary of __construct
     * @param int $id
     * @param Name $username
     * @param string $login
     */
    public function __construct(int $id, Name $username, string $login)
    {
        $this->id = $id;
        $this->username = $username;
        $this->login = $login;
    }

    public function __toString():string
    {
        return "Юзер $this->id с именем $this->username и логином $this->login." . PHP_EOL;
    }
    /**
     * Summary of id
     * @return int
     */
    public function getId():int
    {
        return $this->id;
    }

     /**
      * @param int $id
      */
     public function setId(int $id):void
     {
        $this->id = $id;
     }

    /**
     * @return string
     */
    public function getUsername():string
    {
        return $this->username;
    }

    /**
     * Summary of setUsername
     * @param Name $username
     * @return void
     */
    public function setUsername(Name $username):void
    {
        $this->username = $username;
    }
}