<?php
namespace GeekBrains\LevelTwo\Blog\Exceptions;

class UserNotFoundException extends AppException
{

}