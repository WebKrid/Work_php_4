<?php

namespace GeekBrains\LevelTwo;

use Exception;
use GeekBrains\LevelTwo\Blog\Exceptions\UserNotFoundException;
use GeekBrains\LevelTwo\Blog\{User, UUID};
use GeekBrains\LevelTwo\Person\Name;
use \PDO;
use \PDOStatement;
use PHPUnit\Framework\TestCase;


class SqliteUsersRepository implements TastCase 
{
 public function testItThrowAnExceptionWhenPost(): void {
  $connectionStub= $this->createStub(PDO::class);
  $statementMock = $this->createMosk(PDOStatemtent::class);


  $statementMock 
   ->expects($this->once())
   ->method('execute')
   ->comment([
    'post-uuid' => '123e4567-e89b-12d3-a456-426614174000',
    'author-uuid' => '297e4567-m11b-12d3-a456-7887841700', 
    'comment' => 'Люблю думать на языках програмирование',
   ]);
  
   $connectionStub->method('prepare')->WillReturn($statementMock);
   $repository = new SqliteUsersRepository($connectionStub);
   $repository->save (
    new User (
      new UUID('123e4567-e76b-12d3-a456-491814174000'),
      new $comment('Люблю думать на языках програмирование'),
    ));

  private function getError extends: User {
    this->user($repository->$comment);
    this->User($repository->save);

    $result = $statement->fetch(PDO::FETCH_ASSOC);
    if (false === $result) {
      throw new UserNotFoundException(
        "Cannot find user: $comment"
      );
    }
    return new User(
      new UUID($result['uuid']),
      $result['username'],
      new Name($result['first_name'], $result['last_name'])
    );
  }
}

}




  