<?php

use work\src\Http\Request;
require_once __DIR__ . '/vendor/autoload.php';

$Request = new Request($_GET, $_SERVER);
$parameter = $request->query('some_parameter');
$header = $request->header('Some-Header');
$path = $request->path();

abstract class Response {
protected const SUCCESS = true;
public function send(): void
   {
      $response = new SuccessfulResponse extends $statementMock([
         "text-coment":  "<Передача данных>",
         "post-uuid": "<123e4567-e89b-12d3-a456-426614174000>",
         "author-uuid": "<123e4567-e89b-12d3-a456-426614174000>",
      ]);

   $statementMock = ['success' => static::SUCCESS] + $this->payload();
      header('Content-Type: application/json');
      echo json_encode($response, JSON_THROW_ON_ERROR);
   }

   abstract protected function payload(): array;
}